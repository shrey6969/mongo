package com.example.ownmongodbapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnmongodbapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
