package com.example.ownmongodbapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ownmongodbapi.model.Student;
import com.example.ownmongodbapi.repository.StudentRepo;

@RestController
public class StudentController {
	@Autowired
	StudentRepo studentrepo;
	
	@PostMapping("/addStudent")
	public String addStudent(@RequestBody Student stu) {
		studentrepo.save(stu);
		return "addedd successfully";
	}
	
	@GetMapping("/display")
	public List<Student> display(){
		return studentrepo.findAll();	
	}
	
	@DeleteMapping("/delete/{sid}")
	public String delete(@PathVariable int sid) {
		studentrepo.deleteById(sid);
		return "deleted successfully";
	}
	
	@PutMapping("/update/{sid}")
	public String update(@RequestBody Student stu,@PathVariable int sid) {
		studentrepo.deleteById(sid);
		studentrepo.save(stu);
		return "updated successfully";
	}
}
