package com.example.ownmongodbapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwnmongodbapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OwnmongodbapiApplication.class, args);
	}

}
