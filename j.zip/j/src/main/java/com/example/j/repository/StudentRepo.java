package com.example.j.repository;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.j.model.Student;

public interface StudentRepo extends MongoRepository<Student, Integer>{

}
