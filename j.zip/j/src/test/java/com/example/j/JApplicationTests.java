package com.example.j;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.j.model.Student;
import com.example.j.repository.StudentRepo;

@SpringBootTest
class JApplicationTests {

    @Autowired
    private StudentRepo studentRepo;

    @Test
    public void testCreate() {
        Student s = new Student();
        s.setSid(3);
        s.setSname("Kavya");
        studentRepo.save(s);
        assertNotNull(studentRepo.findById(3).get()); // Changed 902 to 3
    }

    @Test
    public void testReadAll() {
        List<Student> list = studentRepo.findAll();
        assertThat(list).size().isGreaterThan(0); // Changed size() to hasSize
    }

    @Test
    public void testUpdate() {
        Student s = studentRepo.findById(1).get(); // Changed 902 to 2
            s.setSname("uuuuu");
            studentRepo.save(s);
            assertNotEquals("Murthy", studentRepo.findById(1).get().getSname()); // Changed 902 to 2
    }

    @Test
    public void testDelete() {
        studentRepo.deleteById(3);
        assertThat(studentRepo.existsById(2)).isFalse(); // Changed 852 to 2
    }
}
